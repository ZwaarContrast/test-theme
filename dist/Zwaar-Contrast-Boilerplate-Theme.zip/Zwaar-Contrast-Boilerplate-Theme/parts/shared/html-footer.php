<?php
/**
 * HTML footer
 *
 * @package 	WordPress
 * @subpackage 	Zwaar Contrast Boilerplate
 * @since 		Zwaar Contrast Boilerplate 1.0
 */
 ?>

	<?php wp_footer(); ?>
	</body>
</html>